# descriptions
这是浙江大学体系结构课程的lab5和lab6的实现


## lab5

- [x] implement FU_div
- [x] implement FU_mul
- [ ] implement FU_mem
- [ ] implement FU_jump
- [ ] implement RV32core
- [x] implement CtrlUnit

## lab6
> unreleased

